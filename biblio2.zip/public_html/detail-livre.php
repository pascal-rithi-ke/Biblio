<?php include('header.php') ?>
<center>
<?php
//bdd
include('database.php');
//requete detail livre
$requete=$bdd->query('SELECT isbn,titre,nom,prenom,genre.libelle as genre,langue.libelle as langue,nbpages,editeur.libelle as editeur,annee,role.libelle as role FROM `auteur`
join role on auteur.idRole=role.id
join personne on auteur.idPersonne=personne.id
join livre on auteur.idLivre=livre.isbn
JOIN genre on livre.genre=genre.id
JOIN editeur on livre.editeur=editeur.id
JOIN langue on livre.langue=langue.id
order by titre');
?>
<h2>Détail Livre</h2>
<?php while($bdd=$requete->fetch()) { ?>
<hr><b>
<?php 
//affiche les données de la requete
echo 'Titre : '.$bdd['titre'].'<br>'.'Isbn : '.$bdd['isbn'].'<br>'.'Editeur : '.$bdd['editeur'].'<br>'.'Nom : '.$bdd['nom'].' Prenom : '.$bdd['prenom'].'<br>'.'Genre : '.$bdd['genre'].'<br>'.'Langue : '.$bdd['langue'].'<br>'.'Année : '.$bdd['annee'].'<br>'.'Nb pages : '.$bdd['nbpages']?></b>
<?php } ?>
</center><br>
<?php include('footer.php');?>