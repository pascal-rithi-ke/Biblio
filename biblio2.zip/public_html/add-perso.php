<?php
//bdd
include('database.php');
?>
<?php
include('header.php');
?>
<center>
<h2>Ajout Personne/Role</h2>
<a href="ajouter.php"><input type="submit" value="Retour"></a><hr>
<?php
if(isset($_POST['id']) AND isset($_POST['libelle'])){ 
   $id=$_POST['id'];
   $libelle=$_POST['libelle'];
  
   $requete = $bdd->prepare("INSERT INTO `personne`(`id`,`libelle`)VALUES(?,?)");
    $requete->execute(array($_POST['id'] , $_POST['libelle']));
}
?><?//formulaire ajout personne?>
<form method="POST">
<label for="id" name='id'>id personne</label><br>
    <input type="number" name='id'placeholder="Id personne" required><br>

<label for="libelle" name='libelle'>Personne</label><br>
<input type="text" name='libelle'placeholder="Personne" required><br><br>
<?//affiche les personnes déjà présent?>
<?php
$option_per="SELECT * FROM `personne`";
try{
    $stmt_per=$bdd->prepare($option_per);
    $stmt_per->execute();
    $results_per=$stmt_per->fetchAll();
}
catch(Exception $ex)
{
    echo($ex->getMessage());
}
?>
<label for="idPersonne" name='idPersonne'>Personne</label><br>
    <select name="idPersonne" >
    <option>Personne Enregistré</option>
    <?php foreach($results_per as $output_per){?>
    <option value="<?php echo $output_per["id"];?>"><?php echo $output_per["id"].".".$output_per["prenom"].' '.$output_per['nom']?></optiton>
    <?php } ?>
    </select></br>
    <br><input type="submit" value="Validé" OnClick="return confirm('Voulez-vous ajouter cet auteur ?');"> <br><hr>
</form>
<?//formulaire ajout role?>
<form>
<?php
if(isset($_POST['id']) AND isset($_POST['libelle'])){ 
   $id=$_POST['id'];
   $libelle=$_POST['libelle'];
  
   $requete = $bdd->prepare("INSERT INTO `role`(`id`,`libelle`)VALUES(?,?)");
    $requete->execute(array($_POST['id'] , $_POST['libelle']));
}
?>
<form method="POST">
<label for="id" name='id'>id role</label><br>
    <input type="number" name='id'placeholder="Id role" required><br>

<label for="libelle" name='libelle'>Role</label><br>
<input type="text" name='libelle'placeholder="Role" required><br><br>
<?//affiche les roles déjà présent?>
<?php
$option_role="SELECT * FROM `role`";
try{
    $stmt_role=$bdd->prepare($option_role);
    $stmt_role->execute();
    $results_role=$stmt_role->fetchAll();
}
catch(Exception $ex)
{
    echo($ex->getMessage());
}
?>
<label for="idRole" name='idRole'>Role</label><br>
    <select name="idRole" >
    <option>Role Enregistré</option>
    <?php foreach($results_role as $output_role){?>
    <option value="<?php echo $output_role["id"];?>"><?php echo $output_role["id"].".".$output_role["libelle"];?></optiton>
    <?php } ?>
    </select><br>
    <br><input type="submit" value="Validé" OnClick="return confirm('Voulez-vous ajouter cette langue ?');"> <br>
</form>
</center>
<?php include('footer.php') ?>