<?php
//connexion bdd
include('database.php');
?>
<?php
include('header.php');
?>
<?// insert les editeurs genre langue?>
<h2>Ajouter Edit/Genre/Langue</h2>
<a href="ajouter.php"><input type="submit" value="Retour"></a><hr>
<?php
if(isset($_POST['id']) AND isset($_POST['libelle'])){ 
   $id=$_POST['id'];
   $libelle=$_POST['libelle'];
  
   $requete = $bdd->prepare("INSERT INTO `editeur`(`id`,`libelle`)VALUES(?,?)");
    $requete->execute(array($_POST['id'] , $_POST['libelle']));
}
?>
<?//formulaire ajout editeur role langue?>
<form method="POST">
<label for="id" name='id'>id editeur</label><br>
    <input type="number" name='id'placeholder="Id editeur" required><br>

<label for="libelle" name='libelle'>Editeur</label><br>
<input type="text" name='libelle'placeholder="Editeur" required><br><br>

<?php
$option_edi="SELECT * FROM `editeur`";
try{
    $stmt_edi=$bdd->prepare($option_edi);
    $stmt_edi->execute();
    $results_edi=$stmt_edi->fetchAll();
}
catch(Exception $ex)
{
    echo($ex->getMessage());
}
?>
<?// affiche les éditeurs en déroulant?>
<label for="editeur" name='editeur'>Editeur déjà présent</label><br>
    <select name="editeur" >
    <option>Editeur Enregistré</option>
    <?php foreach($results_edi as $output_edi){?>
    <option value="<?php echo $output_edi["id"];?>"><?php echo $output_edi["id"].".".$output_edi["libelle"];?></optiton>
    <?php } ?>
    </select></br>
    <br><input type="submit" value="Validé" OnClick="return confirm('Voulez-vous ajouter cette éditeur ?');"> <br><hr>
</form>
<?//formulaire ajout genre?>
<form>
<?php
if(isset($_POST['id']) AND isset($_POST['libelle'])){ 
   $id=$_POST['id'];
   $libelle=$_POST['libelle'];
  
   $requete = $bdd->prepare("INSERT INTO `genre`(`id`,`libelle`)VALUES(?,?)");
    $requete->execute(array($_POST['id'] , $_POST['libelle']));
}
?>
<form method="POST">
<label for="id" name='id'>id genre</label><br>
    <input type="number" name='id'placeholder="Id genre" required><br>

<label for="libelle" name='libelle'>Genre</label><br>
<input type="text" name='libelle'placeholder="Genre" required><br><br>
<?// affiche les genres en déroulant?>
<?php
$option_genre="SELECT * FROM `genre` order by id asc";
try{
    $stmt_genre=$bdd->prepare($option_genre);
    $stmt_genre->execute();
    $results_genre=$stmt_genre->fetchAll();
}
catch(Exception $ex)
{
    echo($ex->getMessage());
}
?>
<label for="genre" name='genre'>Genre déjà présent</label><br>
    <select name="genre" >
    <option>Genre Enregistré</option>
    <?php foreach($results_genre as $output_genre){?>
    <option value="<?php echo $output_genre["id"];?>"><?php echo $output_genre["id"].".".$output_genre["libelle"];?></optiton>
    <?php } ?>
    </select></br>
    <br><input type="submit" value="Validé" OnClick="return confirm('Voulez-vous ajouter ce genre ?');"> <br><hr>
</form>

<?//formulaire ajout langue?>
<form>
<?php
if(isset($_POST['id']) AND isset($_POST['libelle'])){ 
   $id=$_POST['id'];
   $libelle=$_POST['libelle'];
  
   $requete = $bdd->prepare("INSERT INTO `langue`(`id`,`libelle`)VALUES(?,?)");
    $requete->execute(array($_POST['id'] , $_POST['libelle']));
}
?>
<form method="POST">
<label for="id" name='id'>id langue</label><br>
    <input type="number" name='id'placeholder="Id langue" required><br>

<label for="libelle" name='libelle'>Langue</label><br>
<input type="text" name='libelle'placeholder="Langue" required><br><br>
<?// affiche les langues en déroulant?>
<?php
$option_langue="SELECT * FROM `langue`";
try{
    $stmt_langue=$bdd->prepare($option_langue);
    $stmt_langue->execute();
    $results_langue=$stmt_langue->fetchAll();
}
catch(Exception $ex)
{
    echo($ex->getMessage());
}
?>
<label for="langue" name='langue'>Langue déjà présente</label><br>
    <select name="langue" >
    <option>Langue Enregistré</option>
    <?php foreach($results_langue as $output_langue){?>
    <option value="<?php echo $output_langue["id"];?>"><?php echo $output_langue["id"].".".$output_langue["libelle"];?></optiton>
    <?php } ?>
    </select><br>
    <br><input type="submit" value="Validé" OnClick="return confirm('Voulez-vous ajouter cette langue ?');"> <br><hr>
</form>
</center>
<?php include('footer.php'); ?>