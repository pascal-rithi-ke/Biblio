
<?php
//affiche les données
$requete=$bdd->query('SELECT isbn,titre,nom,prenom,genre.libelle as genre,langue.libelle as langue,editeur.libelle as editeur,annee, FROM `auteur`
join personne on auteur.idPersonne=personne.id
join livre on auteur.idLivre=livre.isbn
JOIN genre on livre.genre=genre.id
JOIN editeur on livre.editeur=editeur.id
JOIN langue on livre.langue=langue.id');
// barre de recherche
if(isset($_GET['q']) AND !empty($_GET['q'])){ 
$q=htmlspecialchars($_GET['q']);
$requete=$bdd->query('SELECT isbn,titre,nom,prenom,genre.libelle as genre,langue.libelle as langue,editeur.libelle as editeur,annee,personne.id FROM `auteur`
join personne on auteur.idPersonne=personne.id
join livre on auteur.idLivre=livre.isbn
JOIN genre on livre.genre=genre.id
JOIN editeur on livre.editeur=editeur.id
JOIN langue on livre.langue=langue.id
WHERE personne.id ="'.$q.'"');
}

?>

<center>
<form method="GET">
<?php
//affiche les informations de la bdd
$option_per="SELECT * FROM `personne`";
try{
    $stmt_per=$bdd->prepare($option_per);
    $stmt_per->execute();
    $results_per=$stmt_per->fetchAll();
}
catch(Exception $ex)
{
    echo($ex->getMessage());
}
?>
</center>

<label for="q" name='q'>Auteur</label><br>
    <select name="q" >
    <option>Recherche par Auteur</option>
    <?php foreach($results_per as $output_per){?>
    <option value="<?php echo $output_per["id"];?>"><?php echo $output_per["id"].".".$output_per["prenom"].' '.$output_per['nom']?></optiton>
    <?php } ?>
    </select></br>
<input type="submit" value="search">
</form>
<?php while($bdd=$requete->fetch()) { ?>
<hr><?= $bdd['titre'].'<br>'.$bdd['isbn'].'<br>'.$bdd['editeur'].'<br>'.$bdd['nom'].' '.$bdd['prenom']?><hr>
<?php } ?>