<?php
// ouvre la session
session_start();
//ferme la session
session_destroy();
//vide la session
$_SESSION=array();
//redirection dans la page login
header("Location: login.php");
exit();
?>