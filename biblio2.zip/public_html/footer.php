</div></center>
    <div class="col-sm-2 sidenav">
                <?php include('minichat.php')?>
    </div>
  </div>
</div>
<a href="#Home"><img id="fleche" src="img/fleche.png"></a>
<footer class="container-fluid text-center">
  <p>Project Pascal Kien & Killyan</p>
</footer>
</body>
</html>