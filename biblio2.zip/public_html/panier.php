<?php
include('database.php');
include('header.php');
?>
<center>
<?php if(!isset($_SESSION['id']))
    { ?>
    <?php }else{?>
   <?php echo "<h2>"."Panier de ".$_SESSION['pseudo']."</h2>";?>
       <?php } ?><br>
<p>Livre dans le Panier</p><hr>
<?php
//récuper les données de catalogue.php puis affiche selon valeur checkbox
    if(isset($_POST['add'])){
        $envoyer=$_POST['checkbox'];
        foreach($envoyer as $isbn) {
          $add=$bdd->query('SELECT prix,titre,isbn FROM livre WHERE isbn ="'.$isbn.'"');
          echo $isbn.'<br>'.'<hr>';
        }
    }
?>
</center>
<?php include('footer.php'); ?>