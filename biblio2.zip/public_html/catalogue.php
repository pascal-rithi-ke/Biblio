<?php
include('database.php');
include('header.php');
?>
<h2>Catalogue Livre De La BDD</h2>
<a href="effacer.php"><input type="submit" value="Retour"></a><hr>
<?php
$sql=$bdd->query('SELECT * from livre order by annee desc;');
?>
<center>
    <?// formulaire catalogue envoie les données dans panier.php ?>
    <form method="POST" action="panier.php">
    <table border="1">
        <tr>
        <th></th>
        <th>Liste des Livres</th>
        </tr>
    <?php
    while ($row=$sql->fetch())
    {
        //affiche les données
        echo "<tr>";
        echo "<td><input type='checkbox' name='checkbox[]' value='".$row['isbn']."<br>".$row['prix'].'€'."<br>".$row['titre']."'></td>
        <td>
        Titre :".$row['titre']."<br> Année :".$row['annee'].'<br>'.'Prix :'.$row['prix'].'€'."</td>";
        echo "</tr>";
    }
    ?>
</table>
<br><input type="submit" name="add" id="add" value="Ajouter Panier" OnClick="return confirm('Voulez-vous vraiment ajouter au panier ?');" /><hr>
</form>
<?php include('footer.php'); ?>