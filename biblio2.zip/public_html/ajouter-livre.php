<?php
//bdd
include('database.php');
?>
<?php include ('header.php'); ?>
<h1>Ajouter un livre</h1>
<a href="ajouter.php"><input type="submit" value="Retour"></a><hr>
<?php
//insert les données
if(isset($_POST['titre']) AND isset($_POST['isbn']) AND isset($_POST['editeur']) AND isset($_POST['genre'])AND isset($_POST['annee'])AND isset($_POST['langue'])AND isset($_POST['nbpages'])){ 
   $titre=$_POST['titre'];
   $isbn=$_POST['isbn'];
   $editeur = $_POST['editeur'];
   $genre = $_POST['genre'];
   $annee = $_POST['annee'];
   $langue = $_POST['langue'];
   $nbpages = $_POST['nbpages'];
   
   $requete = $bdd->prepare("INSERT INTO livre(titre , isbn , editeur ,genre, annee , langue , nbpages )VALUES(?,?,?,?,?,?,?)");
    $requete->execute(array($_POST['titre'] , $_POST['isbn'] ,$_POST['editeur'] ,$_POST['genre'] , $_POST['annee'] ,$_POST['langue'] ,$_POST['nbpages'] ));
}
?>
<table><td>
<?//formulaire?>
<form method="POST">
<label for="titre" name='titre'>Titre</label><br>
    <input type="text" name='titre'placeholder="titre" required> <br>

    <label for="isbn" name='isbn'>Isbn</label> <br>
    <input type="text" name='isbn'placeholder="isbn" required> <br> 
<?//affiche les editeurs déjà présentent?>
<?php
$option_edi="SELECT * FROM `editeur`";
try{
    $stmt_edi=$bdd->prepare($option_edi);
    $stmt_edi->execute();
    $results_edi=$stmt_edi->fetchAll();
}
catch(Exception $ex)
{
    echo($ex->getMessage());
}
?>
<label for="editeur" name='editeur'>Editeur</label><br>
    <select name="editeur" >
    <option>Editeur Enregistré</option>
    <?php foreach($results_edi as $output_edi){?>
    <option value="<?php echo $output_edi["id"];?>"><?php echo $output_edi["libelle"];?></optiton>
    <?php } ?>
    </select></br>



<?//affiche les genres déjà présentent?>
<?php
$option_genre="SELECT * FROM `genre`";
try{
    $stmt_genre=$bdd->prepare($option_genre);
    $stmt_genre->execute();
    $results_genre=$stmt_genre->fetchAll();
}
catch(Exception $ex)
{
    echo($ex->getMessage());
}
?>
<label for="genre" name='genre'>Genre</label><br>
    <select name="genre" >
    <option>Genre Enregistré</option>
    <?php foreach($results_genre as $output_genre){?>
    <option value="<?php echo $output_genre["id"];?>"><?php echo $output_genre["libelle"];?></optiton>
    <?php } ?>
    </select>

 <br><label for="annee" name='annee'>Année</label><br>
    <input type="number" name='annee'placeholder="annee" required min=1500> <br> 

<?//affiche les langues déjà présentent?>
<?php
$option_langue="SELECT * FROM `langue`";
try{
    $stmt_langue=$bdd->prepare($option_langue);
    $stmt_langue->execute();
    $results_langue=$stmt_langue->fetchAll();
}
catch(Exception $ex)
{
    echo($ex->getMessage());
}
?>
<label for="langue" name='langue'>langue</label><br>
    <select name="langue" >
    <option>Langue Enregistré</option>
    <?php foreach($results_langue as $output_langue){?>
    <option value="<?php echo $output_langue["id"];?>"><?php echo $output_langue["libelle"];?></optiton>
    <?php } ?>
    </select>

    <br><label for="nbpage" name='nbpages'>nbpage</label><br>
    <input type="number" name='nbpages' placeholder="nbpage"required min=5 > <br> 
    
    <br></td></table>
    <a href="index.php"><input type="submit" value="Validé" OnClick="return confirm('Voulez-vous ajouter ?');"></a><br>
</form>

<br><a href="add-langue.php">Ajouter Editeur/Genre/Langue</a>
</center><br><hr>
<?php include('footer.php') ?>