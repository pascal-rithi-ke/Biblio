 <?php include('database.php');?>
    <h1>Bienvenue</h1><hr>
    
<?php
// fetch pour aller chercher la requete
   while($bdd = $sql->fetch()){
?> <b>
    <p>Titre :<?php  echo $bdd['titre']; ?></p>
    <p>Auteur :<?php echo $bdd['nom'] ." ". $bdd['prenom'] ;?></p>
     <p>Role :<?php echo $bdd['role'];?>
     <p>Editeur :<?php echo $bdd['editeur'] ;?></p>
     <p>Genre :<?php echo $bdd['genre'] ;?></p></b>

<?php
//image par défaut s'il n'y a pas d'img lié isbn
$defaut="img/default.jpg";
$couverture='img/'.$bdd['isbn'].'.jpg';
if(file_exists($couverture)){
$img=$couverture;
}else{
    $img=$defaut;
}
print'<img src="'.$img.'"/>';
?>
<hr>
    <?php
   }
    ?>
<?php
   //fermeture de ma requete
    $sql->closeCursor(); 
    ?>

