<?php include('header.php'); ?><br>
<?// page de modification?>
<h2>Option Modifier</h2>
<center><br>
<table><td>
<a href=""></a><br>
<br><a href="modifier-livre.php">Modifier Un Livre Dans La BDD</a><br>
<br><a href="">Modifier Compte (Pas encore Fais)</a><br>
</td></table>
</center>
<?php include('footer.php'); ?>