<?php include('header.php'); ?><br>
<center>
<h2>Modifie Un Livre Dans La Bdd</h2>
<a href="modifier.php"><input type="submit" value="Retour"></a><hr>
<?php
//bdd
include('database.php');
//
if(isset($_POST['titre']) AND isset($_POST['isbn']) AND isset($_POST['editeur']) AND isset($_POST['genre'])AND isset($_POST['annee'])AND isset($_POST['langue'])AND isset($_POST['nbpages'])){ 
    $titre=$_POST['titre'];
    $isbn=$_POST['isbn'];
    $editeur = $_POST['editeur'];
    $genre = $_POST['genre'];
    $annee = $_POST['annee'];
    $langue = $_POST['langue'];
    $nbpages = $_POST['nbpages'];
// update le livre selon l'isbn
$sql=$bdd->prepare("UPDATE `livre` SET `titre`=?,`editeur`=?,`annee`=?,`genre`=?,`langue`=?,`nbpages`=? WHERE isbn=?");
$sql->execute(array($_POST['titre'] , $_POST['isbn'] ,$_POST['editeur'] ,$_POST['genre'] , $_POST['annee'] ,$_POST['langue'] ,$_POST['nbpages'] ));
}
?>
<?// formulaire modification?>
<form method="POST">
<label>Isbn</label><br>
<input type="text" name="isbn" placeholder="isbn Livre à changer" required><br>
<label>Titre</label><br>
<input type="text" name="titre" placeholder="Titre"required><br>
<label>Editeur</label><br>
<input type="number" name="editeur" placeholder="id Editeur"required min=1><br>
<label>Annee</label><br>
<input type="number" name="annee" placeholder="Annee"required><br>
<label>Genre</label><br>
<input type="number" name="genre" placeholder="id Genre" required min=1><br>
<label>Langue</label><br>
<input type="number" name="langue" placeholder="id Langue" required min=1><br>
<label>Nb pages</label><br>
<input type="number" name="nbpages" placeholder="Nb pages" required min=5><br>
<input type="submit" value="valider">
</form><br>
<?php // affiche toutes les données déjà dans la bdd ?>
<?php
$option_livre="SELECT isbn,titre FROM `livre`";
try{
    $stmt_livre=$bdd->prepare($option_livre);
    $stmt_livre->execute();
    $results_livre=$stmt_livre->fetchAll();
}
catch(Exception $ex)
{
    echo($ex->getMessage());
}
?>
<label for="titre" name='titre'>Titre enregistré</label><br>
    <select name="titre" >
    <option>Titre Enregistré</option>
    <?php foreach($results_livre as $output_livre){?>
    <option value="<?php echo $output_livre["isbn"];?>"><?php echo $output_livre["isbn"].".".$output_livre["titre"];?></optiton>
    <?php } ?>
    </select></br>
<?php /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// ?>
<?php
$option_edi="SELECT * FROM `editeur`";
try{
    $stmt_edi=$bdd->prepare($option_edi);
    $stmt_edi->execute();
    $results_edi=$stmt_edi->fetchAll();
}
catch(Exception $ex)
{
    echo($ex->getMessage());
}
?>
<label for="editeur" name='editeur'>Editeur enregistré</label><br>
    <select name="editeur" >
    <option>Editeur Enregistré</option>
    <?php foreach($results_edi as $output_edi){?>
    <option value="<?php echo $output_edi["id"];?>"><?php echo 'Id:'.$output_edi["id"].".".$output_edi["libelle"];?></optiton>
    <?php } ?>
    </select></br>
<?php /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// ?>
<?php
$option_genre="SELECT * FROM `genre` order by id asc";
try{
    $stmt_genre=$bdd->prepare($option_genre);
    $stmt_genre->execute();
    $results_genre=$stmt_genre->fetchAll();
}
catch(Exception $ex)
{
    echo($ex->getMessage());
}
?>
<label for="genre" name='genre'>Genre enregistré</label><br>
    <select name="genre" >
    <option>Genre Enregistré</option>
    <?php foreach($results_genre as $output_genre){?>
    <option value="<?php echo $output_genre["id"];?>"><?php echo 'Id:'.$output_genre["id"].".".$output_genre["libelle"];?></optiton>
    <?php } ?>
    </select></br>
<?php /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// ?>
<?php
$option_langue="SELECT * FROM `langue`";
try{
    $stmt_langue=$bdd->prepare($option_langue);
    $stmt_langue->execute();
    $results_langue=$stmt_langue->fetchAll();
}
catch(Exception $ex)
{
    echo($ex->getMessage());
}
?>
<label for="langue" name='langue'>Langue enregistré</label><br>
    <select name="langue" >
    <option>Langue Enregistré</option>
    <?php foreach($results_langue as $output_langue){?>
    <option value="<?php echo $output_langue["id"];?>"><?php echo 'Id:'.$output_langue["id"].".".$output_langue["libelle"];?></optiton>
    <?php } ?>
    </select><br>
    </center><br>
<?php include('footer.php'); ?>