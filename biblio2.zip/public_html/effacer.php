<?php include('header.php'); ?>
<?// page option effacer?>
<h2>Option Ajout</h2>
<center><br>
<table><td>
<a href="effacer-livre.php">Effacer Livre De La Bdd</a><br>
<br><a href="">Effacer Utilisateur(Pas Encore Fais)</a><br>
<br><a href="">Effacer Message Chat(Pas Encore Fais)</a><br>
<br><a href="">Effacer Donées BDD(Pas Encore Fais)</a><br>
</td></table>
</center>
<?php include('footer.php'); ?>