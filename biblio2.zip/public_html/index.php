<?php include('header.php') ?>
<?// page accueil affiche les livres?>
<?php if(!isset($_SESSION['id']))
    { ?>
    <?php }else{?>
   <?php echo "Session de ".$_SESSION['pseudo'];?>
       <?php } ?>
<?php include('liste-livre.php') ?>
<?php include('footer.php')?>