<?php
//connexion bdd
include('database.php');
?>
<?php
include('header.php');
?>
<center>
<?// insert les auteurs ?>
<h2>Associer à l'auteur</h2>
<a href="ajouter.php"><input type="submit" value="Retour"></a><hr>
<?php
if(isset($_POST['idPersonne']) AND isset($_POST['idLivre']) AND isset($_POST['idRole'])){ 
   $personne=$_POST['idPersonne'];
   $isbn=$_POST['idLivre'];
   $role = $_POST['idRole'];
  
   $requete = $bdd->prepare("INSERT INTO auteur(idPersonne , idLivre , idRole)VALUES(?,?,?)");
    $requete->execute(array($_POST['idPersonne'] , $_POST['idLivre'] ,$_POST['idRole']));
}
?>
<?// formulaire ajout des auteurs?>
<form method="POST">
<?php
$option_per="SELECT * FROM `personne`";
try{
    $stmt_per=$bdd->prepare($option_per);
    $stmt_per->execute();
    $results_per=$stmt_per->fetchAll();
}
catch(Exception $ex)
{
    echo($ex->getMessage());
}
?>
<?// affiche les auteurs en déroulant?>
<label for="idPersonne" name='idPersonne'>Personne</label><br>
    <select name="idPersonne" >
    <option>Personne Enregistré</option>
    <?php foreach($results_per as $output_per){?>
    <option value="<?php echo $output_per["id"];?>"><?php echo $output_per["prenom"].' '.$output_per['nom']?></optiton>
    <?php } ?>
    </select></br>
<?// affiche les options en déroulant?>
    <?php
$option_livre="SELECT isbn,titre FROM `livre`";
try{
    $stmt_livre=$bdd->prepare($option_livre);
    $stmt_livre->execute();
    $results_livre=$stmt_livre->fetchAll();
}
catch(Exception $ex)
{
    echo($ex->getMessage());
}
?>
<?// affiche les titres en déroulant?>
<label for="idLivre" name='idLivre'>Livre</label><br>
    <select name="idLivre" >
    <option>Livre Enregistré</option>
    <?php foreach($results_livre as $output_livre){?>
    <option value="<?php echo $output_livre["isbn"];?>"><?php echo $output_livre["titre"];?></optiton>
    <?php } ?>
    </select><br>
<?// affiche les roles en déroulant?>
<?php
$option_role="SELECT * FROM `role`";
try{
    $stmt_role=$bdd->prepare($option_role);
    $stmt_role->execute();
    $results_role=$stmt_role->fetchAll();
}
catch(Exception $ex)
{
    echo($ex->getMessage());
}
?>
<label for="idRole" name='idRole'>Role</label><br>
    <select name="idRole" >
    <option>Role Enregistré</option>
    <?php foreach($results_role as $output_role){?>
    <option value="<?php echo $output_role["id"];?>"><?php echo $output_role["libelle"];?></optiton>
    <?php } ?>
    </select>
    <br>
    <br><input type="submit" value="Validé" OnClick="return confirm('Voulez-vous ajouter ?');"> <br>
</form>
</center>
<?php include('footer.php'); ?>