<?php
session_start();
include('database.php');
if (isset($_POST['mdp']) AND isset($_POST['mail'])){
   $mdp=($_POST['mdp']);
    //$hash=password_hash($_POST['mdp'],PASSWORD_BCRYPT);
    $mail=htmlspecialchars($_POST['mail']);
    // si mail et mdp non rempli
    if(!empty($mail)AND !empty($mdp)){
    //cherche dans la bdd si mdp et mail existe
    $requser=$bdd->prepare("SELECT * FROM inscription where mail=? AND mdp=?");
    $requser->execute(array($mail,$mdp));
    $userexist=$requser->rowCount();
    //si l'utilisateur existe
    if($userexist == 1)
    {
        $userinfo=$requser->fetch();
        $_SESSION['id']=$userinfo['id'];
        $_SESSION['pseudo']=$userinfo['pseudo'];
        $_SESSION['mail']=$userinfo['mail'];
        $_SESSION['statut']=$userinfo['statut'];
        $_SESSION['src']=$userinfo['src'];
        $_SESSION['date_inscript']=$userinfo['date_inscript'];
        if($userinfo['statut']!="user"){
       header("Location: index.php");
    }else{
        //redirection 
        header("Location: affiche-profil.php" );
    }
    }else{
        echo '<center>'.'<br>'."Compte non-existant ou erreur saisie".'</center>';
    }  
    }else
    {
        echo '<center>'.'<br>'."Compte non-existant ou erreur saisie".'</center>';
    }
}
?>
<?php include('header.php'); ?>
<center>
<h2>Connexion</h2>
<?// formulaire login?>
<form method="POST">
<label>mail</label><br>
<input type="mail" placeholder="mail" name ="mail" id="mail"required></input><br>
<label>mot de passe</label><br>
<input type="password" placeholder="mot de passe" name="mdp" id="mdp"required></input><br>
<br><input type="submit" value="Connexion"></input><br>
</form>

<br><a href="inscription.php"><input type="submit" value="Inscription"></input></a><br>
</center>
<?php include('footer.php') ?>