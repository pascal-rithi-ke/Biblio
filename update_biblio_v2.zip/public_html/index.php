<?php include('header.php') ?>
        <h1>Problème base donnée héberger<br> (je vais voir ce soir)</h1>
          <a href="https://la-bibliotheque.000webhostapp.com/img/erreur.PNG">voir photo erreur</a>
<?php include('barre-de-recherche.php')?>
    </div>
    <div class="col-sm-8 text-left" id="mid"><center>
<?// page accueil affiche les livres?>
<?php if(!isset($_SESSION['id']))
    { ?>
    <?php }else{?>
   <?php echo "Session de ".$_SESSION['pseudo'];?>
       <?php } ?>
<?php include('liste-livre.php') ?>
<?php include('footer.php')?>