<?php include('header.php') ?>
    </div>
    <div class="col-sm-8 text-left" id="mid"><center>
<?// page équipe?>
    <style>div.groupe{padding-top:80px}</style>
    <div class="groupe">
     <h1>Groupe G9</h1>
     <p>Kien eng Pascal SLAM</p>
     <p>Rigal Killyan SISR</p><br>
     <p>Compte admin: project@gmail.fr</p>
     <p>mdp: "Flavie-****N"</p>
      <a href="https://github.com/pascal-rithi-ke/Biblio">Lien vers projet Git</a><br>
      <br><p>Schéma entité assosiation de la BDD :</p>
      <a href="https://la-bibliotheque.000webhostapp.com/img/schéma-entité-update.PNG">voir schéma</a>
    </div><br>
<?php include('footer.php');?>