
<?php
include('header-inscrit.php');
include('database.php');
//affiche donnée profil
if(isset($_GET['id']) AND $_GET['id']>0)
{
    
    $getid=intval($_GET['id']);
    $sql=$bdd->prepare("SELECT * FROM inscription where id =? ");
    $sql->execute(array($getid));
    $userinfo=$sql->fetch();
}
echo '<h2>'.'Bienvenue '.$userinfo['pseudo'].'</h2>';
echo '<p>'.('<img style="width:100px;height:100px;" src="'.$userinfo['src'].'"/><br/>').'<table>'.'<td>'.'Profil de : '.$userinfo['pseudo'].'<br>'.'Email : '.$userinfo['mail'].'<br>'.'Inscription : '.$userinfo['date_inscript'].'<br>'.'Statut : '.$userinfo['statut'].'</td>'.'</table>'.'</p>'
?>
<?php include('footer.php'); ?>
