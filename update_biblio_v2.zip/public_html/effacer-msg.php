<?php
//bdd
include('database.php');
?>
<?php
include('header.php');
?>    </div>
    <div class="col-sm-8 text-left" id="mid"><center><br>
<h2>Effacer message du Chat</h2>
<a href="effacer.php"><input type="submit" value="Retour"></a><hr>
<b><p>Du plus réçent au plus vieux</p></b>
<?php
// requete affiche les msg
$sql=$bdd->query("SELECT `id`,`pseudo`,`message`,`envoyer` FROM `chat` order by envoyer desc");
?>
<body>

<center>
    <?//formualire suppresion msg?>
    <form method="POST">
    <table border="1">
        <tr>
        <th></th>
        <th>Liste des messages</th>
        </tr>
    <?php
    // affiche les msg
    while ($row=$sql->fetch())
    {
        echo "<tr>";
        echo "<td><input type='checkbox' name='checkbox[]' value='".$row['id']."'></td>
        <td>
        Pseudo : ".$row['pseudo']."<br> Msg : ".$row['message'].'<br>'.'date : '.$row['envoyer']."</td>";
        echo "</tr>";
// effacer les utilisateurs selon la valeur de checkbox 
    if(isset($_POST['dl'])){
        $envoyer=$_POST['checkbox'];
        foreach ($envoyer as $id) {
          $delete=$bdd->query('DELETE FROM chat WHERE id ="'.$id.'"');
        }
    }
    }
    echo"</table>";
    ?>
    <br><input type="submit" name="dl" id="dl" value="Supprimer" OnClick="return confirm('Voulez-vous supprimer le(s) message(s) ?');" />

    <br><hr></form>
<?php include('footer.php'); ?>