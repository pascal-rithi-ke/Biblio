<?php
//bdd
include('database.php');
?>
<?php
include('header.php');
?>
    </div>
    <div class="col-sm-8 text-left" id="mid"><center><br>
<h2>Effacer Utilisateur De La BDD</h2>
<a href="effacer.php"><input type="submit" value="Retour"></a><hr>
<?php
// requete affiche les utilisateurs
$sql=$bdd->query("SELECT `id`,`pseudo`,`mail`,`statut`,`date_inscript` FROM `inscription` where id>1 ORDER BY statut,date_inscript desc");
?>
<body>

<center>
    <?//formualire suppresion utilisateur?>
    <form method="POST">
    <table border="1">
        <tr>
        <th></th>
        <th>Liste des utilisateurs</th>
        </tr>
    <?php
    // affiche les utilisateurs
    while ($row=$sql->fetch())
    {
        echo "<tr>";
        echo "<td><input type='checkbox' name='checkbox[]' value='".$row['id']."'></td>
        <td>
        Pseudo :".$row['pseudo']."<br> Mail :".$row['mail'].'<br>'.'Statut :'.$row['statut']."<br>".'rejoind :'.$row['date_inscript']."</td>";
        echo "</tr>";
// effacer les utilisateurs selon la valeur de checkbox 
    if(isset($_POST['dl'])){
        $envoyer=$_POST['checkbox'];
        foreach ($envoyer as $id) {
          $delete=$bdd->query('DELETE FROM inscription WHERE id ="'.$id.'"');
        }
    }
    }
    echo"</table>";
    ?>
    <br><input type="submit" name="dl" id="dl" value="Supprimer" OnClick="return confirm('Voulez-vous supprimer utilisateur ?');" />

    <br><hr></form>
<?php include('footer.php'); ?>