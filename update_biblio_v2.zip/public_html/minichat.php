<br><center>
    <b><p>Chat</p></b>
    <?// formualire envoie les données dans minichat_post?>
     <?php if(!isset($_SESSION['id']))
    { ?>
    <b><p>| Connectez vous pour parlez |</p></b><hr>
    <?php }?>
     <?php if(isset($_SESSION['id']))
    { ?>
    <a href="full-screen.php"><input type="submit" value="Full screen" /></a>
    <form method="post" action="minichat_post.php">
        <input type="hidden" name="pseudo" id="pseudo" value="<?php echo $_SESSION['pseudo'] ?>" required/><br>
        <label for="message">Message</label><br><input type="text" name="message" id="message" required/><br />
        <input type="submit" value="Envoyer" /><br><hr>
    </form>
        <?php }?>
<style>
div.msg {height: 425px;width: 225px;overflow-y: scroll;}</style>
<div id="msg">
<?php
// Connexion à la base de données
include('database.php');
// Récupération les derniers messages
$reponse = $bdd->query('SELECT pseudo, message,envoyer FROM chat ORDER BY envoyer desc');

// Affichage de chaque message (toutes les données sont protégées par htmlspecialchars)
while ($donnees = $reponse->fetch())
{
    echo '<p>'.'<b>'.($donnees['pseudo']).'<br>'.''.($donnees['message']).'</b>'.'<br>'.($donnees['envoyer']).'</p>'.'<hr>';
}
?>
</div>
</center>