<?php include('header.php'); ?>
    </div>
    <div class="col-sm-8 text-left" id="mid"><center><br>
<center>
<h2>Modifie compte</h2>
<a href="affiche-profil.php"><input type="button" value="Retour"/></a><hr>
<?php
//bdd
include('database.php');
//
if(isset($_POST['pseudo']) AND isset($_POST['mdp']) AND isset($_POST['mail']) AND isset($_POST['src'])){ 
    $pseudo=$_POST['pseudo'];
    $mdp=$_POST['mdp'];
    $src=$_POST['src'];
    $mail = $_POST['mail'];

$sql=$bdd->prepare("UPDATE inscription SET
pseudo='".$_POST['pseudo']."',
mdp='".$_POST['mdp']."',
src='".$_POST['src']."',
mail='".$_POST['mail']."',
WHERE id='".$_SESSION['id']."'");

$sql->execute(array($_POST['pseudo'] , $_POST['mdp'] ,$_POST['src'] ,$_POST['mail']));
}
?>
<br><form method="POST">
<label>Pseudo</label><br><input type="text" name="pseudo" placeholder="Changer Pseudo"><br>
<label>Photo</label><br><input type="text" name="src" placeholder="Lien seulement de photo "><br>
<label>Mail</label><br><input type="mail" name="mail" placeholder="Changer de mail"><br>
<br><input type="submit" value="valider">
</form>

<center>
<?php include('footer.php'); ?>