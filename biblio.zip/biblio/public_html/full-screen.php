<?php
//bdd
include('database.php');
?>
<?php
include('header.php');
?>    </div>
    <div class="col-sm-8 text-left" id="mid"><center><br>
<h2>Chat Full-screen</h2>
<?php
// requete affiche les msg
$sql=$bdd->query("SELECT `id`,`pseudo`,`message`,`envoyer` FROM `chat` order by envoyer desc");
?>
<center>
    <?//formualire affiche msg?>
    <form method="POST">
    <table border="1">
        <tr>
        <th></th>
        <th>Message du Chat</th>
        </tr>
    <?php
    // affiche les msg
    while ($row=$sql->fetch())
    {
        echo "<tr>";
        echo "<td></td>
        <td>
        Pseudo : ".$row['pseudo']."<br> Msg : ".$row['message'].'<br>'.'date : '.$row['envoyer']."</td>";
        echo "</tr>";
    }
    echo"</table>";
    ?>
    <br><hr>
    </form>
</center>
<?php include('footer.php'); ?>