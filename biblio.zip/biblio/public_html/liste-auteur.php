<?php include('header.php');?>
    </div>
    <div class="col-sm-8 text-left" id="mid"><center>
<h1>Liste des auteurs</h1>
    
<?php
//affiche les données auteurs
include('database.php');
$requete=$bdd->query('SELECT isbn,titre,nom,prenom,genre.libelle as genre,langue.libelle as langue,editeur.libelle as editeur,annee,role.libelle as role FROM `auteur`
join role on auteur.idRole=role.id
join personne on auteur.idPersonne=personne.id
join livre on auteur.idLivre=livre.isbn
JOIN genre on livre.genre=genre.id
JOIN editeur on livre.editeur=editeur.id
JOIN langue on livre.langue=langue.id');
// données dans la barres de recherches auteurs
if(isset($_GET['q']) AND !empty($_GET['q'])){ 
$q=htmlspecialchars($_GET['q']);
$requete=$bdd->query('SELECT isbn,titre,nom,prenom,genre.libelle as genre,langue.libelle as langue,editeur.libelle as editeur,annee,role.libelle as role,personne.id FROM `auteur`
join personne on auteur.idPersonne=personne.id
join role on auteur.idRole=role.id
join livre on auteur.idLivre=livre.isbn
JOIN genre on livre.genre=genre.id
JOIN editeur on livre.editeur=editeur.id
JOIN langue on livre.langue=langue.id
WHERE personne.id ="'.$q.'"');
}

?>

<?// Formulaire recherche par auteur?>
<form method="GET">
<?php
$option_per="SELECT * FROM `personne`";
try{
    $stmt_per=$bdd->prepare($option_per);
    $stmt_per->execute();
    $results_per=$stmt_per->fetchAll();
}
catch(Exception $ex)
{
    echo($ex->getMessage());
}
?>

<center>
    <select name="q" >
    <option>Recherche par Auteur</option>
    <?php foreach($results_per as $output_per){?>
    <option value="<?php echo $output_per["id"];?>"><?php echo $output_per["id"].".".$output_per["prenom"].' '.$output_per['nom']?></optiton>
    <?php } ?>
    </select></br>
<input type="submit" value="search">
</form>
<a href="liste-auteur.php"><input type="button" value="affiche tout"></a>
<?php while($bdd=$requete->fetch()) { ?>
<hr><b>
<?php echo $bdd['titre'].'<br>'.$bdd['isbn'].'<br>'.$bdd['editeur'].'<br>'.$bdd['nom'].' '.$bdd['prenom'].'<br>'.$bdd['genre'].'<br>'.$bdd['langue'].'<br>'.$bdd['annee']?></b>
<?php } ?>
<?php include('footer.php');?>