<?php include('header.php'); ?>
    </div>
    <div class="col-sm-8 text-left" id="mid"><center><br>
<?// page de modification?>
<h2>Option Modifier</h2>
<center><br>
<table><td>
<a href=""></a><br>
<br><a href="modifier-livre.php">Modifier Un Livre Dans La BDD</a><br>
</td></table>
</center>
<?php include('footer.php'); ?>