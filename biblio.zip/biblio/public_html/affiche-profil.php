<?php 
include('header.php') ?>
    </div>
    <div class="col-sm-8 text-left" id="mid"><center>
<?php
//affiche le profil
echo '<h2>'.'Bienvenue '.$_SESSION['pseudo'].'</h2>';
echo '<p>'.('<img style="width:100px;height:100px;" src="'.$_SESSION['src'].'"/><br/>').'<table>'.'<td>'.'Profil de : '.$_SESSION['pseudo'].'<br>'.'Email : '.$_SESSION['mail'].'<br>'.'Inscription : '.$_SESSION['date_inscript'].'<br>'.'Statut : '.$_SESSION['statut'].'</td>'.'</table>'.'</p>'
?>
<table><td><a href="historique.php">Historique réservation</a>
<br><a href="modifier-compte.php">Modifier Compte</a><br></td></table>

<?php include('footer.php')?>