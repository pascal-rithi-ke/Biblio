<?php
include('database.php');

// Insertion du message à l'aide d'une requête préparée
$req = $bdd->prepare('INSERT INTO chat (pseudo, message) VALUES(?,?)');
$req->execute(array( $_POST['pseudo'], $_POST['message']));
header('Location: full-screen.php');
?>