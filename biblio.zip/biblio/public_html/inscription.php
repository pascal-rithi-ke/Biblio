<?php
//bdd
include('database.php');
//
if (isset($_POST['pseudo']) AND isset($_POST['mdp']) AND isset($_POST['mdp2']) AND isset($_POST['mail']) AND isset($_POST['mail2']) AND isset($_POST['src'])){
    $pseudo=htmlspecialchars($_POST['pseudo']);

    $mdp=($_POST['mdp']);
    //$hash=password_hash($_POST['mdp'],PASSWORD_BCRYPT);

    $mdp2=($_POST['mdp2']);
    //$hash2=password_hash($_POST['mdp2'],PASSWORD_BCRYPT);

    $mail=htmlspecialchars($_POST['mail']);
    $mail2=htmlspecialchars($_POST['mail2']);

    $src=$_POST['src'];
// vérifier la saisie des deux mails
     if($mail==$mail2){
//requete
         $reqmail=$bdd->prepare("SELECT * FROM inscription where mail=?");
         $reqmail->execute(array($mail));
// compare le nombre de colonne dans la bdd table inscription
         $mailexist=$reqmail->rowCount();
         //vérifier si le mail existe déjà
         if($mailexist==0){
             //compare les 2 mdps
            if($mdp==$mdp2){
                // si les conditions sont bonnes alors insert dans la table inscription
                 $requete = $bdd->prepare("INSERT INTO `inscription`(pseudo,mdp,mail,src)VALUES(?,?,?,?)");
                 $requete->execute(array($pseudo , $mdp,$mail,$src));
                    if($requete){
                       echo '<center>'."Inscription Réussi".'</center>'; 
                    }else{
                        echo '<center>'."Echec Inscription".'</center>';
                    }
        }else{echo '<center>'."Erreur  mdp".'</center>';}
     }else{echo '<center>'."Erreur mail existant ou erreur saisie ".'</center>';}
    }else{echo '<center>'."Erreur mail existant ou erreur saisie,erreur mdp ".'</center>';}

    
   


}
?>
<?php include('header.php'); ?>
<center>
    <?//formulaire inscription?>
<form method="POST">

<h2>Inscription</h2>

<label>pseudo</label><br>
<input type="text" placeholder="pseudo" id="pseudo" name="pseudo" value="<?php if(isset($pseudo))?>" required><br>

<label>mail</label><br>
<input type="mail" placeholder="mail" id="mail" name="mail" value="<?php if(isset($mail))?>"required><br>
<input type="mail" placeholder="confirmation mail" id="mail2" name="mail2" value="<?php if(isset($mail2))?>"required><br>

<label>mot de passe</label><br>
<input type="password" placeholder="mot de passe" id="mdp" name="mdp"required><br>
<input type="password" placeholder="confirmation mot de passe" id="mdp2" name="mdp2"required><br>

<label>photo profil</label><br>
<input type="text" placeholder="lien internet image " id="src" name="src" required><br>

<br>
<input type="submit" name="confirm" id="confirm" value="confirm" OnClick="return confirm('Vos données sont bonnes ?');" />

</form>
<br><a href="login.php"><input type="submit" value="Retour"></input></a><br>
</center>
<?php include('footer.php') ?>
