<?php include('header.php'); ?>
    </div>
    <div class="col-sm-8 text-left" id="mid"><center>
<?// page option effacer?>
<h2>Option Ajout</h2>
<center><br>
<table><td>
<a href="effacer-livre.php">Effacer Livre De La Bdd</a><br>
<br><a href="supprimer_utilisateur.php">Effacer Utilisateur</a><br>
<br><a href="effacer-msg.php">Effacer Message Chat</a><br>
</td></table>
</center>
<?php include('footer.php'); ?>