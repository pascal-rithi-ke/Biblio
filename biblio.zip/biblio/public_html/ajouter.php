<?php include('header.php'); ?>
    </div>
    <div class="col-sm-8 text-left" id="mid"><center>
<?// page option ajouter?>
<h2>Option Ajout</h2>
<center><br>
<table><td>
<a href="ajouter-livre.php">Etape 1.Ajouter Un Livre Dans La Bdd</a><br>
<br><a href="add-auteur.php">Etape 2.Associer Une Personne aux Livres Crées</a><br>
<br><a href="add-langue.php">Ajouter Un Editeur/Genre/Langue Dans La Bdd</a><br>
<br><a href="add-perso.php">Ajouter Une Personne Dans La Bdd</a><br>
</td></table>
</center>
<?php include('footer.php'); ?>