<?php
include('header.php');
?>
    </div>
    <div class="col-sm-8 text-left" id="mid"><center>
<?php
//requete detail livre
$requete=$bdd->query('SELECT id_livre,mail_client,rendu from panier where mail_client="'.$_SESSION['mail'].'"');
?>
<h2>Historique des achats</h2>
<a href="affiche-profil.php"><input type="button" value="Retour"/></a><hr>
<?php while($bdd=$requete->fetch()) { ?>
<hr><b>
<table>
<td>
<?php 
//affiche les données de la requete
echo '-'.'Livre : '.$bdd['id_livre'].'<br>'.'mail : '.$bdd['mail_client'].'<br>'.'Rendre le : '.$bdd['rendu']?></b>
<?php } ?>
</td></table>
<?php
include('footer.php');
?>