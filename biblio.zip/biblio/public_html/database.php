<?php
/*Lignes de commande connection a la base de donnée */
try{
$bdd = new PDO('mysql:host=localhost;dbname=id12482392_bibliotheque;charset=utf8','//','//');
}
catch (Exception $e)
{
die('Erreur : ' . $e->getMessage());
}
//Permet de mieux voir les erreurs
$bdd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
?>
