<?php
//bdd
include('database.php');
?>
<?php
include('header.php');
?>    </div>
    <div class="col-sm-8 text-left" id="mid"><center><br>
<h2>Effacer Livre De La BDD</h2>
<a href="effacer.php"><input type="submit" value="Retour"></a><hr>
<?php
// requete affiche les livres
$sql=$bdd->query('SELECT titre,annee,isbn from livre order by annee desc;');
?>
<body>

<center>
    <?//formualire suppresion livre?>
    <form method="POST">
    <table border="1">
        <tr>
        <th></th>
        <th>Liste des Livres</th>
        </tr>
    <?php
    // affiche les livres
    while ($row=$sql->fetch())
    {
        echo "<tr>";
        echo "<td><input type='checkbox' name='checkbox[]' value='".$row['isbn']."'></td>
        <td>
        Titre :".$row['titre']."<br> Année :".$row['annee']."</td>";
        echo "</tr>";
// effacer les livres selon la valeur de checkbox 
    if(isset($_POST['dl'])){
        $envoyer=$_POST['checkbox'];
        foreach ($envoyer as $isbn) {
          $delete=$bdd->query('DELETE FROM livre WHERE isbn ="'.$isbn.'"');
        }
    }
    }
    echo"</table>";
    ?>
    <br><input type="submit" name="dl" id="dl" value="Supprimer" OnClick="return confirm('Voulez-vous vraiment supprimer ?');" />

    <br><hr></form>
<?php include('footer.php'); ?>